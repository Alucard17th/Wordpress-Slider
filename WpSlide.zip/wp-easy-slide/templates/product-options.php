
<div class="panel-wrap" >

    <div class="tab">
        <button class="demo" onclick="infofunc(event, 'dates')" id="current">General</button>
        <button class="demo" onclick="infofunc(event, 'inventory')">Inventory</button>
        <button class="demo" onclick="infofunc(event, 'sells')">Upsells & Cross-sells</button>
        <button class="demo" onclick="infofunc(event, 'settings')">Advanced Settings</button>
    </div>

        <div id="dates" class="products-tab-container">
        <?php require (WP_PLUGIN_DIR . '/WPPROM/templates/sections/general.php'); ?>
        </div>

        <div id="inventory" class="products-tab-container">
        <?php require (WP_PLUGIN_DIR . '/WPPROM/templates/sections/inventory.php'); ?>
        </div>

        <div id="sells" class="products-tab-container">
        <?php require (WP_PLUGIN_DIR . '/WPPROM/templates/sections/upcross-sells.php'); ?>
        </div>

        <div id="settings" class="products-tab-container">
        <?php require (WP_PLUGIN_DIR . '/WPPROM/templates/sections/settings.php'); ?>
        </div>

</div>

<div class="container">
  <div class="row">
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
  </div>
</div>




<script type="text/javascript" src="/wpcod/wp-content/plugins/WP Cash On Deliery/src/js/modules/jquery-ui.js"></script>
<script type="text/javascript" src="/wpcod/wp-content/plugins/WP Cash On Deliery/src/js/auto-complete.js"></script>
<script>
function infofunc(e, info) {
e.preventDefault();
var i, content, links;
content = document.getElementsByClassName("products-tab-container");
for (i = 0; i < content.length; i++) {
content[i].style.display = "none";
}
links = document.getElementsByClassName("demo");
for (i = 0; i < links.length; i++) {
links[i].className = links[i].className.replace(" active", "");
}
document.getElementById(info).style.display = "block";
e.currentTarget.className += " active";
}
document.getElementById("current").click();

 var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
 removeItemButton: true,
 maxItemCount:5,
 searchResultLimit:5,
 renderChoiceLimit:5
 
 });
</script>

