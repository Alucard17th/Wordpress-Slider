<style>
.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
  margin:5% !important;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.img-container:hover .image {
  opacity: 0.3;
}

.img-container:hover .middle {
  opacity: 1;
}

.slider-field{
  margin:5% !important;

}

</style>

<?php 
      global $post;
      $arraf = get_post_meta($post->ID , 'wpcod_user_settings', true );
?>
<div class="container">
  <button id="frontend-button" class="button" type="button">Add Nexw Slider</button>
 
  <div class="col-12">
       
  
  
    <div class="row" id="imageRows">
              <?php 
              if ($arraf){

                $imageIds =  $arraf['wpes_order_ids'];
                $titles =  $arraf['wpes_slide_name'];
                $descriptions =  $arraf['wpes_slide_desc'];
                $buttons =  $arraf['wpes_slide_button'];
                $buttonsText =  $arraf['wpes_slide_Btext'];
                $buttonsUrl =  $arraf['wpes_slide_Burl'];
                $titleColor =  $arraf['wpes_slide_Titlecolor'];
                $textColor =  $arraf['wpes_slide_Textcolor'];
                $buttonsColor =  $arraf['wpes_slide_Bcolor'];

                foreach ( $imageIds as $key=>$name ) {
                  $result[] = array( 'imageid' => $name, 'title' => $titles[$key], 'descriptions' => $descriptions[ $key ],
                  'buttons' => $buttons[ $key ], 'buttonsText' => $buttonsText[ $key ], 'buttonsUrl' => $buttonsUrl[ $key ],
                  'buttonsColor' => $buttonsColor[ $key ], 'titleColor' => $titleColor[ $key ], 'textColor' => $textColor[ $key ] );
                }

                foreach($result as $postData){
                  $wpres_image_id = $postData['imageid'];
                  $wpes_image = wp_get_attachment_url( $postData['imageid']);
                  $wpes_title = $postData['title'];
                  $wpes_content = $postData['descriptions'];
                  $wpes_button = $postData['buttons'];
                  $wpes_buttonTxt = $postData['buttonsText'];
                  $wpes_buttonUrl = $postData['buttonsUrl'];
                  $wpes_buttonColor = $postData['buttonsColor'];
                  $wpes_titleColor = $postData['titleColor'];
                  $wpes_textColor = $postData['textColor'];
                  $wpes_button_yn = checked( $wpes_button, "yes", false );
                  if($postData["buttonsUrl"] == "yes"){
                    $html .='';
                }

                  
echo "<div class='col-sm-3 img-container'>
<img class='image' class='slider-field' src='$wpes_image' style='width: inherit;'>

<div>
<input type='text' name='fullName[]' class='form-control slider-field' placeholder='Slide Title' value='$wpes_title'>
<span class='dashicons dashicons-arrow-down-alt2 toggle-options'></span>
<div class='options-container'>
<textarea name='slideDescription[]' class='form-control slider-field' placeholder='Slide Description'>$wpes_content</textarea>
<input type='hidden' class='image_order_ids' id='image_ids' name='image_ids[]' value='$wpres_image_id'>
<input type='checkbox' class='check_buttonx form-control slider-field' name='check_button_block[]' value='yes' $wpes_button_yn>
Add Button
<input type='checkbox' class='check_button form-control' name='check_button[]' value='$wpes_button' style='display: none;' checked>
<input type='text' name='buttonText[]' id='button-text' class='form-control slider-field btext' style='display:none;' placeholder='Button Text' value='$wpes_buttonTxt'>
<input type='url' name='buttonUrl[]'  id='button-url' placeholder='Button URL' class='form-control slider-field burl' style='display:none;' value='$wpes_buttonUrl'>

<table>
  <tr>  
    <td>
      <label class='label-color' for='title_color'>Title Color</label>
    </td>
    <td>
      <input type='color' id='tit-color' name='title_color[]' value='$wpes_titleColor'>
    </td>
  </tr>
  <tr>  
    <td>
      <label class='label-color' for='text_color'>Text Color</label>
    </td>
    <td>
      <input type='color' id='txt-color' name='text_color[]' value='$wpes_textColor'>
    </td>
  </tr>
  <tr>  
    <td>
      <label class='label-color' for='button_color'>Button Color</label>
    </td>
    <td>
      <input type='color' id='btn-color' name='button_color[]' value='$wpes_buttonColor'>
    </td>
  </tr>
</table>

</div>
</div>
</div>";

                  

                  
                  }
              }else{
                echo "<div class='container no-slider'><p>Add New Image to create your first Slide.</p></div>";
              }

              
          ?>

    </div>
  
            </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.10.2/Sortable.min.js" integrity="sha512-ELgdXEUQM5x+vB2mycmnSCsiDZWQYXKwlzh9+p+Hff4f5LA+uf0w2pOp3j7UAuSAajxfEzmYZNOOLQuiotrt9Q==" crossorigin="anonymous"></script>
<script type="text/javascript" src="/wpcod/wp-content/plugins/WP Cash On Deliery/src/js/modules/jquery-ui.js"></script>
<script type="text/javascript" src="/wpcod/wp-content/plugins/WP Cash On Deliery/src/js/auto-complete.js"></script>
<script>

function editDiapo(e) {
    e.preventDefault()
    var target = e.target
    var parent = target.parentElement
    parent = parent.parentElement
    var targetForm = jQuery(parent).children('form')
    targetForm.toggle()
    
  }

jQuery( ".toggle-options" ).click(function() {
  jQuery(".options-container").toggle()
  jQuery('.toggle-options').each(function() {
    jQuery(this).toggleClass("dashicons-arrow-up-alt2 dashicons-arrow-down-alt2");
  })
  
});

(function($) {
$(document).ready( function() {

	var file_frame; // variable for the wp.media file_frame
	
	// attach a click event (or whatever you want) to some element on your page
	$( '#frontend-button' ).on( 'click', function( event ) {
		event.preventDefault();

  // if the file_frame has already been created, just reuse it
		if ( file_frame ) {
			file_frame.open();
			return;
		} 

		file_frame = wp.media.frames.file_frame = wp.media({
			title: $( this ).data( 'uploader_title' ),
			button: {
				text: $( this ).data( 'uploader_button_text' ),
			},
			multiple: false // set this to true for multiple file selection
		});

		file_frame.on( 'select', function() {

			attachment = file_frame.state().get('selection').first().toJSON();
      var rowParent = document.getElementById('')

      // create Image Dom column
      var img = document.createElement('img');
      var columnDiv = document.createElement('div');
      var middleDiv = document.createElement('div');
      var middleContentDiv = document.createElement('button');
      var imgIdInput = document.createElement('input');
      var optionsContainer = document.createElement('div');

      
var slideOptions = '<input type="text" name="fullName[]" class="form-control slider-field" placeholder="Slide Title" value="">'+
'<span class="dashicons dashicons-arrow-down-alt2 toggle-options"></span>'+
'<textarea name="slideDescription[]" class="form-control slider-field" placeholder="Slide Description"></textarea>'+
// '<input type="hidden" class="image_order_ids" id="image_ids" name="image_ids[]" value="19">'+
'<input type="checkbox" class="check_buttonx form-control slider-field" name="check_button_block[]" value="yes">'+
'Add Button'+
'<input type="checkbox" class="check_button form-control" name="check_button[]" value="" style="display: none;" checked="">'+
'<input type="text" name="buttonText[]" id="button-text" class="form-control slider-field btext" placeholder="Button Text" value="">'+
'<input type="url" name="buttonUrl[]" id="button-url" placeholder="Button URL" class="form-control slider-field burl" value="">'+
'<div>'+
'<label class="label-color" for="title_color">Title Color</label>'+
'<input type="color" id="tit-color" name="title_color[]" value="">'+
'<label class="label-color" for="text_color">Text Color</label>'+
'<input type="color" id="txt-color" name="text_color[]" value="">'+
'<label class="label-color" for="button_color">Button Color</label>'+
'<input type="color" id="btn-color" name="button_color[]" value=""></div>';
                    
      optionsContainer.innerHTML = slideOptions
     
      // create form for image title and text
      // Create a form dynamically
      var form = document.createElement("div");
      
      img.style.width = "inherit";
      img.setAttribute("class", "image");
      columnDiv.setAttribute("class", "col-sm-3 img-container");
      middleDiv.setAttribute("class", "middle");
      middleContentDiv.setAttribute("class", "text");
      middleContentDiv.setAttribute("onclick", "editDiapo(event)");
      
      imgIdInput.setAttribute("type", "hidden");
      imgIdInput.setAttribute("class", "image_order_ids");
      imgIdInput.setAttribute("ID", "image_ids");
      imgIdInput.setAttribute("name", "image_ids[]");
      middleContentDiv.innerHTML = "Edit"
      optionsContainer.setAttribute("class", "options-container");

      
     
      form.appendChild(imgIdInput);
     
      columnDiv.appendChild(img);
      middleDiv.appendChild(middleContentDiv);
      columnDiv.appendChild(middleDiv);
      columnDiv.appendChild(form);
      columnDiv.appendChild(optionsContainer);

      document.getElementById('imageRows').appendChild(columnDiv);
			// do something with the file here
			//$( '#frontend-button' ).hide();
      imgIdInput.value= attachment.id;
			$( '#frontend-image' ).attr('src', attachment.url);
      $( img ).attr('src', attachment.url);
		});

		file_frame.open();
	});

  new Sortable(imageRows, {
    animation: 150,
    ghostClass: 'blue-background-class'
  });

  $( ".check_buttonx" ).change(function() {
      if(this.checked == true){
        // this.value = 'yes'
        $(this).next('input').val('yes')
        $(this).next().next().show()
        $(this).next().next().next().show()       
        } else {
          // this.value = 'no'
          $(this).next('input').val('no')
          $(this).next().next().hide()
        $(this).next().next().next().hide()
        }
  });

  jQuery('.check_buttonx').each(function() {
      var currentElement = $(this);
    
      var value = currentElement.val(); // if it is an input/select/textarea field
      // TODO: do something with the value

        if($(currentElement).is(':checked')){
              $(currentElement).next().next().show()
              $(currentElement).next().next().next().show()   
             
        }else{
              //$("#txtAge").hide();  // unchecked
              $(currentElement).next().next().hide()
              $(currentElement).next().next().next().hide()   
              
        }
    });


 });

})(jQuery);
</script>

