<h3>Pricing</h3>
<?php 
    global $post;
    $data = get_post_custom($post->ID);

    $val = isset($data['wpcod_price_input']) ? esc_attr($data['wpcod_price_input'][0]) : 'no value';
    echo 'Regular price</br>';
    echo "<input type='text' name='price_input' id='price_input' value='$val' />";
    echo '</br>';

    $val = isset($data['wpcod_sale_price_input']) ? esc_attr($data['wpcod_sale_price_input'][0]) : 'no value';
    echo 'Sale price</br>';

    echo "<input type='text' name='sale_price_input' id='sale_price_input' value='$val' />";
    
    echo "&nbsp <a href='#'>Schedule promotions</a>";
    echo '</br>';

    $val = isset($data['wpcod_datepicker_from']) ? esc_attr($data['wpcod_datepicker_from'][0]) : 'no value';
    echo 'Sales price dates</br>';
    echo "<input type='text'  name='datepicker_from' id='datepicker_from' value='$val' 
    placeholder='From…' maxlength='10' readonly>" ;

    $val = isset($data['datepicker_to']) ? esc_attr($data['datepicker_to'][0]) : 'no value';
    echo '</br></br>';
    echo "<input type='text'  name='datepicker_to' id='datepicker_to' value='$val' 
    placeholder='To…' maxlength='10' readonly>" ;


?>
<script type="text/javascript" src="/wpcod/wp-content/plugins/WP Cash On Deliery/src/js/modules/jquery-1.12.4.js"></script>
<script>
$(function(){
    $("#datepicker_from").datepicker({
        dateFormat: "yy-mm-dd"
    });

    $("#datepicker_to").datepicker({
        dateFormat: "yy-mm-dd"
    });
});
</script>