<?php 
    $arraf = get_post_meta( $a['slidered'], 'wpcod_user_settings', true );
    $imageIds =  $arraf['wpes_order_ids'];
    $titles =  $arraf['wpes_slide_name'];
    $descriptions =  $arraf['wpes_slide_desc'];
    $style =  $arraf['wpes_slide_style'];
        
    $html = '<style>
    .swiper-container {width: 600px;height: 600px;}
    .swiper-slide{background-size: contain; background-repeat: no-repeat; } 
    .swiper-slide img {max-width:100wv;}
    </style><!-- Slider main container -->
    <div class="swiper-container"><!-- Additional required wrapper -->
    <div class="swiper-wrapper"><!-- Slides -->';

    foreach ( $imageIds as $key=>$name ) {
        $result[] = array( 'imageid' => $name, 'title' => $titles[$key], 'descriptions' => $descriptions[ $key ] );
    }

    foreach($result as $postData){
       $html .= '<div class="swiper-slide" style="background-image:url('.wp_get_attachment_url( $postData["imageid"]).')">'.$postData["title"].'</div>';
    }
            
    $html .= '</div>
    <!-- If we need pagination -->
    <div class="swiper-pagination"></div>
    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- If we need scrollbar -->
    <div class="swiper-scrollbar"></div>
    </div>
    <script>
        const swiper = new Swiper(".swiper-container", {
        // Optional parameters
        // If we need pagination
        effect: "fade",
        
        // Navigation arrows
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        // And if we need scrollbar
        scrollbar: {
            el: ".swiper-scrollbar",
        },
        });
    </script>';

?>

       

