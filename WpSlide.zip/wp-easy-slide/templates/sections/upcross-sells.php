<?php global $wpcod; 
$diwp_upsellfield = get_post_meta( $post->ID, 'wpcod_upsells', true);
$diwp_xsellfield = get_post_meta( $post->ID, 'wpcod_cross_sells', true);
?>

<h3>Sells</h3>  
<div class="container mt-1">
    <div class="row">
        <div class="text-left">
            <div class="label">Upsells</div>
            <select id="select-up" name="upsells[]" multiple>
            <?php foreach($diwp_upsellfield as $selected) { ?>
            <option value="<?php echo $selected; ?>" selected><?php echo get_the_title( $selected ); ?></option>
            <?php } ?>
            <?php foreach($wpcod as $product) { ?>
            <option  value="<?php echo $wpcod->id; ?>" data-description="<?php echo $wpcod->name; ?>"><?php echo $wpcod->name; ?></option>
            <?php } ?>
            </select>
        </div>
    </div>
</div>

<div class="container mt-1">
    <div class="row">
        <div class="text-left">
            <div class="label">Cross-sells</div>
            <select id="select-cross" name="crossells[]" multiple>
            <?php foreach($diwp_xsellfield as $selected) { ?>
            <option value="<?php echo $selected; ?>" selected><?php echo get_the_title( $selected ); ?></option>
            <?php } ?>
            <?php foreach($wpcod as $product) { ?>
            <option  value="<?php echo $wpcod->id; ?>" data-description="<?php echo $wpcod->name; ?>"><?php echo $wpcod->name; ?></option>
            <?php } ?>
            </select>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/tail.select@0.5.15/js/tail.select-full.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tail.select@0.5.15/css/default/tail.select-light.css">

    <script>
       tail.select('#select-up',{
        search: true,
        descriptions: true,
        multiLimit: 5,
        hideSelected: true,
        hideDisabled: true,
        multiShowCount: false,
        multiContainer: true,
       });
       tail.select('#select-cross',{
        search: true,
        descriptions: true,
        multiLimit: 5,
        hideSelected: true,
        hideDisabled: true,
        multiShowCount: false,
        multiContainer: true,
       });
    </script>