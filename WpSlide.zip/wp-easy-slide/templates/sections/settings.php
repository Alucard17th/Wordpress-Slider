<?php
global $post;
$diwp_textareafield = get_post_meta( $post->ID, 'wpcod_purchase_note', true);
$diwp_checkboxfield = get_post_meta( $post->ID, 'wpcod_reviews_action', true);


?>
<h3>Settings</h3>
        
            <div class="label">Purchase Note</div>
                <div class="fields">
                    <textarea rows="5" cols="80" name="purchase_note"><?php echo $diwp_textareafield; ?></textarea>
                </div>
        
        
            <div class="fields">
                <label><input type="checkbox" value ="1" name="reviews_action[]" <?php if(in_array('1', $diwp_checkboxfield)) echo 'checked'; ?>   /> Enable reviews</label>
                <label style="display:none;" ><input  type="checkbox" value ="2" name="reviews_action[]" <?php if(in_array('2', $diwp_checkboxfield)) echo 'checked'; ?> /> Checkbox Option 2</label>
            </div>
       
        <br/>