<?php 
        global $post;
         // Get Value of Fields From Database
         $diwp_textfield = get_post_meta( $post->ID, 'wpcod_stock_quantity', true);
         $diwp_radiofield = get_post_meta( $post->ID, '_diwp_radio_field', true);
         $diwp_checkboxfield = get_post_meta( $post->ID, 'wpcod_manage_stock', true);
         $diwp_selectfield = get_post_meta( $post->ID, 'wpcod_stock_status', true);
    ?>
<h3>Centre</h3>

    <div class="label">Manage Stock </div>
        <div class="fields">
            <label><input id="manage_stocks" type="checkbox"  name="manage_stocks[]" <?php if(in_array('on', $diwp_checkboxfield)) echo 'checked'; ?>   /> Enable stock management</label>
            <label style="display:none;" ><input  type="checkbox"  name="manage_stocks[]" <?php if(in_array('2', $diwp_checkboxfield)) echo 'checked'; ?> /> Checkbox Option 2</label>
        </div>

<div  id="stock_quantity_settings" style="display: <?php echo (in_array('on', $diwp_checkboxfield)) ? 'block' : 'none' ?>;">
    <div class="label">Quantity in stock</div>
        <div class="fields">
            <input type="text" name="stock_quantity" value="<?php echo $diwp_textfield; ?>">
        </div>
</div>

<div  id="stock_status_settings" style="display: <?php echo (in_array('on', $diwp_checkboxfield)) ? 'none' : 'block' ?>;">
    <div class="label">Stock status</div>
        <div class="fields">
           <select name="stock_status">
           <option <?php if($diwp_selectfield=='') echo 'selected'; ?>>Choose an option</option>
            <option <?php if($diwp_selectfield=='In stock') echo 'selected'; ?>>In stock</option>
            <option <?php if($diwp_selectfield=='Out of stock') echo 'selected'; ?>>Out of stock</option>
           </select>
        </div>
</div>
        

        
        