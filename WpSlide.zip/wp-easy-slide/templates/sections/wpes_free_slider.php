<?php 
        $arraf = get_post_meta( $a['slidered'], 'wpcod_user_settings', true );
        $imageIds =  $arraf['wpes_order_ids'];
        $titles =  $arraf['wpes_slide_name'];
        $descriptions =  $arraf['wpes_slide_desc'];
        $style =  $arraf['wpes_slide_style'];
        
    $html = '<style>
       .swiper-container {width: 100%;height: 600px;}
       .swiper-slide{background-size: contain; background-repeat: no-repeat; } 
       .swiper-slide img {max-width:100wv;}
        </style><!-- Slider main container -->

    <div class="swiper-container"><!-- Additional required wrapper -->
        <div class="swiper-wrapper"><!-- Slides -->';

           foreach ( $imageIds as $key=>$name ) {
                $result[] = array( 'imageid' => $name, 'title' => $titles[$key], 'descriptions' => $descriptions[ $key ] );
            }

    foreach($result as $postData){
      $html .= '<div class="swiper-slide" style="background-image:url('.wp_get_attachment_url( $postData["imageid"]).')">'.$postData["title"].'</div>';
    }
            
      $html .= '</div>
            <!-- If we need pagination -->
            <div class="swiper-pagination"></div>
            <!-- If we need navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
            <!-- If we need scrollbar -->
            <div class="swiper-scrollbar"></div>
    </div>
      
      
<script>
    var swiper = new Swiper(".swiper-container", {
        slidesPerView: 3,
        spaceBetween: 30,
        freeMode: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
</script>';

       

