<?php 
global $post;
$arraf = get_post_meta($post->ID , 'wpcod_user_settings', true );
$short_code = "[wpeasyslide slidered='$post->ID']";
if (isset($arraf['wpes_slide_style'])){

?> 


<div class="container">
    <select id="sliderStyle" name="sliderStyle">
    <option value="1" <?php selected( $arraf['wpes_slide_style'], 1 );?>>Normal Slider</option>
    <option value="2" <?php selected( $arraf['wpes_slide_style'], 2 ); ?>>Slider With Pagination</option>
    <option value="3" <?php selected( $arraf['wpes_slide_style'], 3 ); ?>>Vertical Slider</option>
    <option value="4" <?php selected( $arraf['wpes_slide_style'], 4 ); ?>>Auto Slider</option>
    </select>
    <input type="number" id="slideSpeed" name="slideSpeed" min="1" max="5">
</div>

<?php
}else{?>

<div class="container">
    <select id="sliderStyle" name="sliderStyle">
    <option value="1">Normal Slider</option>
    <option value="2">Slider With Pagination</option>
    <option value="3">Vertical Slider</option>
    <option value="4">Auto Slider</option>
    </select>
    <input type="number" id="slideSpeed" name="slideSpeed" min="1" max="5">
</div>


<?php } ?>

<div class="preference">
<label for="cheese">Short code : </label></br>
<?php echo $short_code; ?>
</div>



<?php
?>