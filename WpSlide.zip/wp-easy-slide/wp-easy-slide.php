<?php
/**
 * @package  wpProjectManager
 */
/*
Plugin Name: WP Easy Slider 2
Plugin URI: https://eddallal-noureddine.space/
Description: Very easy to use Slider plugin, that you can use on pages and posts with shortcode.
Version: 1.0.0
Author: Noureddine Eddallal
Author URI: https://eddallal-noureddine.space/
License: GPLv2 or later
Text Domain: wpcod-plugin
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/

global $wpcod ;

// If this file is called firectly, abort!!!
defined( 'ABSPATH' ) or die( 'Hey, what are you doing here? You silly human!' );

// Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

/**
 * The code that runs during plugin activation
 */
function activate_wpcod_plugin() {
	Inc\Base\Activate::activate();
}
register_activation_hook( __FILE__, 'activate_wpcod_plugin' );

/**
 * The code that runs during plugin deactivation
 */
function deactivate_wpcod_plugin() {
	Inc\Base\Deactivate::deactivate();
}
register_deactivation_hook( __FILE__, 'deactivate_wpcod_plugin' );

/**
 * Initialize all the core classes of the plugin
 */
if ( class_exists( 'Inc\\Init' ) ) {
	Inc\Init::register_services();
}

function register_wpcod_products() {
	Inc\Base\CreateWpcodProducts::registerWpcodProducts();
}
add_action( 'init', 'register_wpcod_products' );

function register_wpcod_metaFields() {
	Inc\Base\CreateWpcodProducts::registerWpcodMetaBoxes();
	
}
add_action('admin_init', 'register_wpcod_metaFields');

function save_wpcod_metaFields() {
	Inc\Base\CreateWpcodProducts::save_detail();
	
}
add_action('save_post', 'save_wpcod_metaFields');

function register_shortcodes($atts) {
	return Inc\Base\ShortCodeController::short_code_register($atts);
	//print_r (Inc\Base\ShortCodeController::short_code_register($atts));
}
add_shortcode( 'wpeasyslide', 'register_shortcodes' );








