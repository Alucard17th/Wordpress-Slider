<?php 
/**
 * @package  wpcodPlugin
 */
namespace Inc\Api\Callbacks;

class WpcodCallbacks
{

    public function custom_metabox_field(){
        
            
            require (WP_PLUGIN_DIR . '/wp-easy-slide/templates/slider-admin-content.php');
       
         }

         public function custom_metabox_field_side(){
        
            
            require (WP_PLUGIN_DIR . '/wp-easy-slide/templates/cpt-metabox-side.php');
       
         }

         

            

}