<?php
/**
 * @package  wpcodPlugin
 */
namespace Inc\Base;

use Inc\Api\Callbacks\WpcodCallbacks;




class CreateWpcodProducts 
{
    public $wpcod_callbacks;
	//public $callbacks;
	public static function registerWpcodProducts() {
		$labels = array(
			'name'                  => _x( 'Slides', 'Post type general name', 'textdomain' ),
			'singular_name'         => _x( 'Slide', 'Post type singular name', 'textdomain' ),
			'menu_name'             => _x( 'Slides', 'Admin Menu text', 'textdomain' ),
			'name_admin_bar'        => _x( 'Slide', 'Add New on Toolbar', 'textdomain' ),
			'add_new'               => __( 'Add New', 'textdomain' ),
			'add_new_item'          => __( 'Add New Slide', 'textdomain' ),
			'new_item'              => __( 'New Slide', 'textdomain' ),
			'edit_item'             => __( 'Edit Slide', 'textdomain' ),
			'view_item'             => __( 'View Slide', 'textdomain' ),
			'all_items'             => __( 'All Slides', 'textdomain' ),
			'search_items'          => __( 'Search Slides', 'textdomain' ),
			'parent_item_colon'     => __( 'Parent Slides:', 'textdomain' ),
			'not_found'             => __( 'No Slide found.', 'textdomain' ),
			'not_found_in_trash'    => __( 'No Slide found in Trash.', 'textdomain' ),
			'featured_image'        => _x( 'Slide Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
			'set_featured_image'    => _x( 'Set Slide image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
			'remove_featured_image' => _x( 'Remove Slide image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
			'use_featured_image'    => _x( 'Use as Slide image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
			'archives'              => _x( 'Slide archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
			'insert_into_item'      => _x( 'Insert into Slide', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
			'uploaded_to_this_item' => _x( 'Uploaded to this Slide', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
			'filter_items_list'     => _x( 'Filter Slides list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
			'items_list_navigation' => _x( 'Slides list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
			'items_list'            => _x( 'Slides list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
		);
	 
		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'book' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title' ),
		);

        register_post_type( 'wpcod_slide', $args );


	}
	

    public static function registerWpcodMetaBoxes() {
        $wpcod_callbacks = new WpcodCallbacks();

		add_meta_box(
			'my_custom_meta_box_id', 
			'My-meta-box-title',
			array( $wpcod_callbacks, 'custom_metabox_field_side' ), 
			'wpcod_slide', 
			'side', 
			'low'
		);

        add_meta_box("custom_metabox_1", "slide Details",array( $wpcod_callbacks, 'custom_metabox_field' ), "wpcod_slide", "advanced", "low");
		
    }

	public static function save_detail(){
		global $post;

		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
			return $post->ID;
		}

		$wpcod_settings_arr = [];
		$slide_images = $_POST["image_ids"];
		
		if(isset($_POST["image_ids"])) :
			update_post_meta($post->ID,'wpes_slide_imagesarray', $_POST["image_ids"]);
			$wpcod_settings_arr['wpes_order_ids'] = $_POST["image_ids"];
		endif;

		if(isset($_POST["fullName"])) :
			update_post_meta($post->ID,'wpes_slide_fullName', $_POST["fullName"]);
			$wpcod_settings_arr['wpes_slide_name'] = $_POST["fullName"];
		endif;

		if(isset($_POST["slideDescription"])) :
			update_post_meta($post->ID,'wpes_slide_description', $_POST["slideDescription"]);
			$wpcod_settings_arr['wpes_slide_desc'] = $_POST["slideDescription"];
		endif;

		if(isset($_POST["check_button"])) :
			update_post_meta($post->ID,'wpes_slide_button', $_POST["check_button"]);
			$wpcod_settings_arr['wpes_slide_button'] = $_POST["check_button"];
		endif;

		if(isset($_POST["buttonText"])) :
			update_post_meta($post->ID,'wpes_slide_Btext', $_POST["buttonText"]);
			$wpcod_settings_arr['wpes_slide_Btext'] = $_POST["buttonText"];
		endif;

		if(isset($_POST["buttonUrl"])) :
			update_post_meta($post->ID,'wpes_slide_Burl', $_POST["buttonUrl"]);
			$wpcod_settings_arr['wpes_slide_Burl'] = $_POST["buttonUrl"];
		endif;

		if(isset($_POST["button_color"])) :
			update_post_meta($post->ID,'wpes_slide_Bcolor', $_POST["button_color"]);
			$wpcod_settings_arr['wpes_slide_Bcolor'] = $_POST["button_color"];
		endif;

		if(isset($_POST["title_color"])) :
			update_post_meta($post->ID,'wpes_slide_Titlecolor', $_POST["title_color"]);
			$wpcod_settings_arr['wpes_slide_Titlecolor'] = $_POST["title_color"];
		endif;

		if(isset($_POST["text_color"])) :
			update_post_meta($post->ID,'wpes_slide_Textcolor', $_POST["text_color"]);
			$wpcod_settings_arr['wpes_slide_Textcolor'] = $_POST["text_color"];
		endif;

		if(isset($_POST["sliderStyle"])) :
			update_post_meta($post->ID,'wpes_slide_style', $_POST["sliderStyle"]);
			$wpcod_settings_arr['wpes_slide_style'] = $_POST["sliderStyle"];
		endif;

		



		update_post_meta($post->ID, 'wpcod_user_settings', $wpcod_settings_arr);
	}

	
    
}