<?php 
/**
 * @package  wpcodPlugin
 */
namespace Inc\Base;

use Inc\Base\BaseController;

/**
* 
*/
class Enqueue extends BaseController
{
	public function register() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action('admin_enqueue_scripts', array( $this, 'enqueue_my_scripts' ) );
		add_action('admin_enqueue_scripts', array( $this, 'enqueue_my_styles' ) );
		add_action('wp_enqueue_scripts', array( $this, 'wp_enqueue' ));
	}
	


function wp_enqueue() {
	wp_enqueue_style( 'swiperjs', 'https://unpkg.com/swiper/swiper-bundle.css' );
	wp_enqueue_script( 'swipercss', 'https://unpkg.com/swiper/swiper-bundle.js' );
	wp_enqueue_style( 'mypluginstyle', $this->plugin_url . 'assets/mystyle.css' );
}

	function enqueue() {
		// enqueue all our scripts
		wp_enqueue_media();
		wp_enqueue_style( 'mypluginstyle', $this->plugin_url . 'assets/mystyle.css' );
		wp_enqueue_script( 'mypluginscript', $this->plugin_url . 'assets/myscript.js' );
	}

	// enqueu all bootstrap scripts and css 
	function enqueue_my_scripts() {
		wp_enqueue_script( 'bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js', array('jquery'), true); // all the bootstrap JavaScript goodness
		wp_enqueue_script( 'jquery', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js', array('jquery'), '1.9.1', true); // we need the jquery library for Bootstrap js to function
	}
		

		function enqueue_my_styles() {
		wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css' );
	}

}