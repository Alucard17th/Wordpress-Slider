<?php
/**
 * @package  wpcodPlugin
 */
namespace Inc\Base;


class Activate 
{
	//public $callbacks;
	public static function activate() {
		flush_rewrite_rules();
		
		$default = array();

		if ( ! get_option( 'wpcod_plugin' ) ) {
			update_option( 'wpcod_plugin', $default );
		}

		if ( ! get_option( 'wpcod_plugin_cpt' ) ) {
			update_option( 'wpcod_plugin_cpt', $default );
		}

	}
}