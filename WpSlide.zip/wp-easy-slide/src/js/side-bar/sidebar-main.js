// SHOW MENU
const showMenu = (toggleId, navbarId,bodyId,secodnavId) =>{
    const toggle = document.getElementById(toggleId),
    navbar = document.getElementById(navbarId),
    bodypadding = document.getElementById(bodyId)
    secondNavPadding = document.getElementById(secodnavId)


    if(toggle && navbar){
        toggle.addEventListener('click', ()=>{
            // APARECER MENU
            //navbar.classList.toggle('show')
            // ROTATE TOGGLE
            toggle.classList.toggle('rotate')
            // PADDING BODY
            bodypadding.classList.toggle('expander')
            secondNavPadding.classList.toggle('second-nav-expander')
            secondNavPadding.classList.toggle('show')

        })
    }
}
showMenu('nav-toggle','navbar','body','navbar2')

// LINK ACTIVE COLOR
const linkColor = document.querySelectorAll('.nav__link');   
function colorLink(){
    linkColor.forEach(l => l.classList.remove('active'));
    this.classList.add('active');
}

linkColor.forEach(l => l.addEventListener('click', colorLink));


