import'code-prettify';


window.addEventListener("load", function() {

	PR.prettyPrint();
	
	// store tabs variables
	var tabs = document.querySelectorAll("ul.nav-tabs > li");
	var manageOptions =  document.querySelector('#manage_stocks');
	var manageDoptionsQ = document.querySelector('#stock_quantity_settings');
	var manageDoptionsS = document.querySelector('#stock_status_settings');


	for (var i = 0; i < tabs.length; i++) {
		tabs[i].addEventListener("click", switchTab);
	}


	manageOptions.addEventListener('change', e => {
    if(e.target.checked){
		manageDoptionsQ.style.display = "block"
		manageDoptionsS.style.display = "none"
    	}else{
		manageDoptionsQ.style.display = "none"
		manageDoptionsS.style.display = "block"
		}
	});

	function switchTab(event) {
		event.preventDefault();

		document.querySelector("ul.nav-tabs li.active").classList.remove("active");
		document.querySelector(".tab-pane.active").classList.remove("active");

		var clickedTab = event.currentTarget;
		var anchor = event.target;
		var activePaneID = anchor.getAttribute("href");

		clickedTab.classList.add("active");
		document.querySelector(activePaneID).classList.add("active");

	}

	

	

});




	

	
